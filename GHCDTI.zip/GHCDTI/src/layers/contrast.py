# import torch
# import torch.nn as nn
#
#
# class Contrast(nn.Module):
#     def __init__(self, out_dim, tau, keys):#不同投影层的键
#         super(Contrast, self).__init__()
#         self.proj = nn.ModuleDict({k: nn.Sequential(
#             nn.Linear(out_dim, out_dim),
#             nn.ELU(),
#             nn.Linear(out_dim, out_dim)
#         ) for k in keys})
#         self.tau = tau
#         for k, v in self.proj.items():
#             for model in v:
#                 if isinstance(model, nn.Linear):
#                     nn.init.xavier_normal_(model.weight,gain=1.414 )
#
#     def sim(self, z1, z2):
#         z1_norm = torch.norm(z1, dim=-1, keepdim=True)
#         z2_norm = torch.norm(z2, dim=-1, keepdim=True)
#         dot_numerator = torch.mm(z1, z2.t())
#         dot_denominator = torch.mm(z1_norm, z2_norm.t())
#         sim_matrix = torch.exp(dot_numerator / dot_denominator / self.tau)
#         return sim_matrix
#
#     def compute_loss(self, z_mp, z_sc, pos, k):
#
#         # import torch
#         # import matplotlib.pyplot as plt
#         #
#         # def sim(self, z1, z2):
#         #     z1_norm = torch.norm(z1, dim=-1, keepdim=True)
#         #     z2_norm = torch.norm(z2, dim=-1, keepdim=True)
#         #     dot_numerator = torch.mm(z1, z2.t())
#         #     dot_denominator = torch.mm(z1_norm, z2_norm.t())
#         #     sim_matrix = torch.exp(dot_numerator / dot_denominator / self.tau)
#         #     return sim_matrix
#         # torch.manual_seed(42)
#         # tau = 0.5
#         # # 计算相似度矩阵
#         # sim_matrix = sim(z_mp, z_sc, tau)
#         #
#         # # 将相似度矩阵展开为一维数组，便于绘图
#         # sim_values = sim_matrix.cpu().numpy().flatten()
#         #
#         # # 绘制相似度分布的直方图
#         # plt.hist(sim_values, bins=50, color='skyblue', edgecolor='black')
#         # plt.title("Similarity Distribution")
#         # plt.xlabel("Similarity")
#         # plt.ylabel("Frequency")
#         # plt.show()
#
#         z_proj_mp = self.proj[k](z_mp)
#         z_proj_sc = self.proj[k](z_sc)
#
#         matrix_mp2sc = self.sim(z_proj_mp, z_proj_sc)
#         matrix_sc2mp = matrix_mp2sc.t()#转置
#
#         matrix_mp2sc = matrix_mp2sc / (torch.sum(matrix_mp2sc, dim=1).view(-1, 1) + 1e-8)
#         lori_mp = -torch.log(matrix_mp2sc.mul(pos.to_dense()).sum(dim=-1)).mean()
#
#         matrix_sc2mp = matrix_sc2mp / (torch.sum(matrix_sc2mp, dim=1).view(-1, 1) + 1e-8)
#         lori_sc = -torch.log(matrix_sc2mp.mul(pos.to_dense()).sum(dim=-1)).mean()
#         return lori_mp + lori_sc
#
#     # def compute_loss(self, z_mp, z_sc, pos, k):
#     #     z_proj_mp = self.proj[k](z_mp)
#     #     z_proj_sc = self.proj[k](z_sc)
#     #
#     #     # 计算余弦相似度
#     #     cosine_sim_mp2sc = torch.nn.functional.cosine_similarity(z_proj_mp, z_proj_sc, dim=-1)
#     #
#     #     # 使用负的余弦相似度作为损失
#     #     loss = (1 - cosine_sim_mp2sc).mean()  # 最大化相似度
#     #     return loss
#     def forward(self, z_mp, z_sc, pos):
#         sumLoss = 0
#         for k, v in pos.items():
#             sumLoss += self.compute_loss(z_mp[k], z_sc[k], pos[k], k)
#         return sumLoss



# HLCL
import torch
import torch.nn as nn


class Contrast(nn.Module):
    def __init__(self, out_dim, tau, keys, num_hierarchies=2):
        super(Contrast, self).__init__()
        self.tau = tau
        self.num_hierarchies = num_hierarchies
        self.proj = nn.ModuleDict({
            k: nn.ModuleList([
                nn.Sequential(
                    nn.Linear(out_dim, out_dim),
                    nn.ELU(),
                    nn.Linear(out_dim, out_dim)
                ) for _ in range(num_hierarchies)
            ]) for k in keys
        })
        for k, v in self.proj.items():
            for hierarchy in v:
                for layer in hierarchy:
                    if isinstance(layer, nn.Linear):
                        nn.init.xavier_normal_(layer.weight, gain=1.414)

    def sim(self, z1, z2):
        z1_norm = torch.norm(z1, dim=-1, keepdim=True)
        z2_norm = torch.norm(z2, dim=-1, keepdim=True)
        dot_numerator = torch.mm(z1, z2.t())
        dot_denominator = torch.mm(z1_norm, z2_norm.t())
        sim_matrix = torch.exp(dot_numerator / dot_denominator / self.tau)
        return sim_matrix

    def compute_loss(self, z_mp, z_sc, pos, k):
        total_loss = 0
        for hierarchy in range(self.num_hierarchies):
            z_proj_mp = self.proj[k][hierarchy](z_mp)
            z_proj_sc = self.proj[k][hierarchy](z_sc)

            matrix_mp2sc = self.sim(z_proj_mp, z_proj_sc)
            matrix_sc2mp = matrix_mp2sc.t()

            matrix_mp2sc = matrix_mp2sc / (torch.sum(matrix_mp2sc, dim=1).view(-1, 1) + 1e-8)
            lori_mp = -torch.log(matrix_mp2sc.mul(pos.to_dense()).sum(dim=-1)).mean()

            matrix_sc2mp = matrix_sc2mp / (torch.sum(matrix_sc2mp, dim=1).view(-1, 1) + 1e-8)
            lori_sc = -torch.log(matrix_sc2mp.mul(pos.to_dense()).sum(dim=-1)).mean()

            total_loss += lori_mp + lori_sc
        return total_loss

    def forward(self, z_mp, z_sc, pos):
        sum_loss = 0
        for k in pos.keys():
            sum_loss += self.compute_loss(z_mp[k], z_sc[k], pos[k], k)
        return sum_loss

#双曲面
# import torch
# import torch.nn as nn
# import geoopt
#
# class HyperbolicLinear(nn.Module):
      #双曲空间中的线性变换层。
#     def __init__(self, in_dim, out_dim):
#         super(HyperbolicLinear, self).__init__()
#         self.manifold = geoopt.PoincareBall()  # 使用 Poincaré Ball 流形
#         self.weight = nn.Parameter(torch.Tensor(out_dim, in_dim))  # 权重矩阵
#         self.bias = nn.Parameter(torch.Tensor(out_dim))  # 偏置项
#         self.reset_parameters()
#
#     def reset_parameters(self):
          #初始化权重和偏置。
#         nn.init.xavier_normal_(self.weight, gain=1.414)  # Xavier 初始化
#         nn.init.zeros_(self.bias)  # 偏置初始化为 0
#
#     def forward(self, x):

#         # 将输入投影到双曲空间
#         x_tangent = self.manifold.logmap0(x)  # 将输入映射到切空间
#         # 在切空间中进行线性变换
#         x_transformed = x_tangent @ self.weight.t() + self.bias
#         # 将结果投影回双曲空间
#         x_hyperbolic = self.manifold.expmap0(x_transformed)
#         return x_hyperbolic
#
# class Contrast(nn.Module):
#     def __init__(self, out_dim, tau, keys):
#         super(Contrast, self).__init__()
#         self.tau = tau
#         self.manifold = geoopt.PoincareBall()  # 使用 Poincaré Ball 流形
#         self.proj = nn.ModuleDict({
#             k: self._build_hyperbolic_projection_layer(out_dim) for k in keys
#         })  # 为每个视角构建双曲投影层
#         self._init_weights()  # 初始化权重
#
#     def _build_hyperbolic_projection_layer(self, out_dim):
          #构建一个双曲空间中的投影层。
#         return nn.Sequential(
#             HyperbolicLinear(out_dim, out_dim),  # 双曲线性层
#             nn.ELU(),  # 激活函数（在切空间中操作）
#             HyperbolicLinear(out_dim, out_dim)  # 双曲线性层
#         )
#
#     def _init_weights(self):
#         for k in self.proj:
#             for layer in self.proj[k]:
#                 if isinstance(layer, HyperbolicLinear):
#                     layer.reset_parameters()
#
#     def sim(self, z1, z2):
          #计算两个特征矩阵的相似度矩阵（使用双曲距离）。
#         dist = self.manifold.dist(z1, z2)  # 使用 Poincaré Ball 流形的 dist 方法
#         sim_matrix = torch.exp(-dist / self.tau)  # 使用温度因子调整
#         return sim_matrix
#
#     def compute_loss(self, z_mp, z_sc, pos, k):
#         z_proj_mp = self.proj[k](z_mp)
#         z_proj_sc = self.proj[k](z_sc)
#
#         matrix_mp2sc = self.sim(z_proj_mp, z_proj_sc)
#         matrix_sc2mp = matrix_mp2sc.t()
#
#         matrix_mp2sc = matrix_mp2sc.unsqueeze(1)
#         matrix_mp2sc = matrix_mp2sc / (torch.sum(matrix_mp2sc, dim=1).view(-1, 1) + 1e-8)
#         lori_mp = -torch.log(matrix_mp2sc.mul(pos.to_dense()).sum(dim=-1)).mean()
#
#         matrix_sc2mp = matrix_sc2mp.unsqueeze(1)
#         matrix_sc2mp = matrix_sc2mp / (torch.sum(matrix_sc2mp, dim=1).view(-1, 1) + 1e-8)
#         lori_sc = -torch.log(matrix_sc2mp.mul(pos.to_dense()).sum(dim=-1)).mean()
#
#         return lori_mp + lori_sc
#
#     def forward(self, z_mp, z_sc, pos):
#         total_loss = 0
#         for k in pos.keys():
#             total_loss += self.compute_loss(z_mp[k], z_sc[k], pos[k], k)
#         return total_loss

