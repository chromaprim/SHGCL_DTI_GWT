# SHGCL-DTI

## Requirements
aiohappyeyeballs    2.5.0
aiohttp             3.11.13
aiosignal           1.3.2
asttokens           3.0.0
async-timeout       5.0.1
attrs               25.1.0
Brotli              1.0.9
certifi             2025.1.31
charset-normalizer  3.3.2
colorama            0.4.6
contourpy           1.3.0
cycler              0.12.1
decorator           5.2.1
dgl                 0.9.0
exceptiongroup      1.2.2
executing           2.2.0
filelock            3.13.1
fonttools           4.56.0
frozenlist          1.5.0
fsspec              2025.3.0
geoopt              0.5.0
gmpy2               2.2.1
idna                3.7
importlib_resources 6.5.2
ipython             8.18.1
jedi                0.19.2
Jinja2              3.1.5
joblib              1.4.2
jsonpickle          4.0.2
kiwisolver          1.4.7
MarkupSafe          3.0.2
matplotlib          3.9.4
matplotlib-inline   0.1.7
mkl_fft             1.3.11
mkl_random          1.2.8
mkl-service         2.4.0
mpmath              1.3.0
multidict           6.1.0
networkx            3.2.1
numpy               2.0.1
packaging           24.2
pandas              2.2.3
parso               0.8.4
pillow              11.1.0
pip                 25.0
prompt_toolkit      3.0.50
propcache           0.3.0
psutil              7.0.0
pure_eval           0.2.3
Pygments            2.19.1
PyGSP               0.5.1
pyparsing           3.2.1
PySocks             1.7.1
python-dateutil     2.9.0.post0
pytz                2025.1
pyvis               0.3.2
PyYAML              6.0.2
requests            2.32.3
scikit-learn        1.6.1
scipy               1.13.1
setuptools          75.8.0
six                 1.17.0
stack-data          0.6.3
sympy               1.13.1
threadpoolctl       3.5.0
torch               2.5.1
torch_cluster       1.6.3+pt25cu124
torch-geometric     2.6.1
torch_scatter       2.1.2+pt25cu124
torch_sparse        0.6.18+pt25cu124
torch_spline_conv   1.2.2+pt25cu124
torchaudio          2.5.1
torchdata           0.11.0
torchvision         0.20.1
tqdm                4.67.1
traitlets           5.14.3
typing_extensions   4.12.2
tzdata              2025.1
urllib3             2.3.0
wcwidth             0.2.13
wheel               0.45.1
win-inet-pton       1.1.0
yarl                1.18.3
zipp                3.21.0
## Quick start

1. cd src/application
2. python `main.py` Options are:
   1. `--device: the gpu used to train model, default:cuda:0`
   2. `--hid_dim: the dimension of hidden layers, default:2048`
   3. `--number: the Postive and Negative ratio, three choice: one--pos:neg=1:1; ten--pos:neg=1:10; all--all unlabelled DTI is treated as neg, default:ten`
   4. `--feature: the feature used in experiment, three choice: random, luo, default(ours), default:default`
   5. `--task: the different scenario to test: choice: benchmark->mat_drug_protein.txt, disease->mat_drug_protein_disease.txt, drug->mat_drug_protein_drug.txt, homo_protein_drug->mat_drug_protein_homo_protein_drug.txt,sideeffect->mat_drug_protein_sideeffect.txt, unique->mat_drug_protein_drug_unique.txt default:benchmark`
   6. `--edge_mask: whether mask some edges in the HN, choice: ''(empty str) drug protein drug,protein disease sideeffect disease,sideeffect drugsim proteinsim drugsim,proteinsim default:''(empty str)'`


## Data description

* `drug.txt` : list of drug names.
* `protein.txt` : list of protein names.
* `disease.txt` : list of disease names.
* `se.txt` : list of side effect names.
* `drug_dict_map.txt` : a complete ID mapping between drug names and DrugBank ID.
* `protein_dict_map.txt`: a complete ID mapping between protein names and UniProt ID.
* `mat_drug_se.txt` : Drug-SideEffect association matrix.
* `mat_protein_protein.txt` : Protein-Protein interaction matrix.
* `mat_drug_drug.txt` : Drug-Drug interaction matrix.
* `mat_protein_disease.txt` : Protein-Disease association matrix.
* `mat_drug_disease.txt` : Drug-Disease association matrix.
* `mat_protein_drug.txt` : Protein-Drug interaction matrix.
* `mat_drug_protein.txt` : Drug-Protein interaction matrix.
* `Similarity_Matrix_Drugs.txt` : Drug similarity scores based on chemical structures of drugs
* `Similarity_Matrix_Proteins.txt` : Protein similarity scores based on primary sequences of proteins
* `mat_drug_protein_homo_protein_drug.txt` : Drug-Protein interaction matrix, in which DTIs with similar drugs (i.e., drug chemical structure similarities > 0.6) or similar proteins (i.e., protein sequence similarities > 40%) were removed (see the paper). 
* `mat_drug_protein_drug.txt` : Drug-Protein interaction matrix, in which DTIs with drugs sharing similar drug interactions (i.e., Jaccard similarities > 0.6) were removed (see the paper). 
* `mat_drug_protein_sideeffect.txt` : Drug-Protein interaction matrix, in which DTIs with drugs sharing similar side effects (i.e., Jaccard similarities > 0.6) were removed (see the paper). 
* `mat_drug_protein_disease.txt` : Drug-Protein interaction matrix, in which DTIs with drugs or proteins sharing similar diseases (i.e., Jaccard similarities > 0.6) were removed (see the paper). 
* `mat_drug_protein_unique.txt` : Drug-Protein interaction matrix, in which known unique and non-unique DTIs were labelled as 3 and 1, respectively, the corresponding unknown ones were labelled as 2 and 0 (see the paper for the definition of unique). 

These files: drug.txt, protein.txt, disease.txt, se.txt, drug_dict_map, protein_dict_map, mat_drug_se.txt, mat_protein_protein.txt, mat_drug_drug.txt, mat_protein_disease.txt, mat_drug_disease.txt, mat_protein_drug.txt, mat_drug_protein.txt, Similarity_Matrix_Proteins.txt, are extracted from https://github.com/luoyunan/DTINet.

These files: mat_drug_protein_homo_protein_drug.txt, mat_drug_protein_drug.txt, mat_drug_protein_sideeffect.txt, mat_drug_protein_disease.txt, mat_drug_protein_unique.txt are extracted from https://github.com/FangpingWan/NeoDTI